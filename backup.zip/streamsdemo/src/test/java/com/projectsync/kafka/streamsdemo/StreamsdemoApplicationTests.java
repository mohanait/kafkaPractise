package com.projectsync.kafka.streamsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamsdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
