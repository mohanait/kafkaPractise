package com.projectsync.kafka.orderproducer;

public class OrderProducerApplication {

    public static void main(String[] args) {

    }
}
