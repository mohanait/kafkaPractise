package com.projectsync.kafka.userConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
