package com.projectsync.kafka.orderconsumer;

public class OrderConsumerApplication {

    public static void main(String[] args) {

    }
}

