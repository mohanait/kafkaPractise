package com.projectsync.kafka.orderconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
class OrderconsumerTests {

/*	@Test
	void contextLoads() {
	}*/

}
