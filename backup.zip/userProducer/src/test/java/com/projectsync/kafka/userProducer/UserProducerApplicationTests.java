package com.projectsync.kafka.userProducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
