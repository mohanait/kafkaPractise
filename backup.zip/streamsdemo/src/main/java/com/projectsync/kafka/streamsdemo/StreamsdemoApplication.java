package com.projectsync.kafka.streamsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// @SpringBootApplication
public class StreamsdemoApplication {

	public static void main(String[] args) {
		// SpringApplication.run(StreamsdemoApplication.class, args);
		System.out.println("Kafka Streams Demo");
	}
}
